create
    definer = root@localhost procedure UsersCount(OUT cnt int)
BEGIN
    select count(*) into cnt from users;
END;

