create
    definer = root@localhost procedure getName(IN nameId int)
BEGIN
    select * from Users where id = nameId;
end;

